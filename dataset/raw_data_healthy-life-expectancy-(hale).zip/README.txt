GLOBAL HEALTH OBSERVATORY DOWNLOAD
====================================
This zip data file has been downloaded from 

	Name: Life expectancy and life tables
	URL: https://www.who.int/data/gho/data/themes/topics/topic-details/GHO/healthy-life-expectancy-(hale)
	Description: 
	WHO�s Global Health Estimates provide the latest available data on causes of death and disability globally, by WHO region and country, by age, sex and by income group.�These estimates are produced using data from multiple sources, including national vital registration data, latest estimates from WHO technical programmes, United Nations partners and inter-agency groups, the Global Burden of Disease and other scientific studies. Before publishing, the GHE are reviewed by WHO Member States via consultation with national focal points and WHO country and regional offices.��Top 10 global causes of death in 2019Top 10 global causes of disability-adjusted life years (DALYs) in 2019Ischaemic heart diseaseStrokeChronic obstructive pulmonary diseaseLower respiratory infectionsNeonatal conditionsTrachea, bronchus, lung cancersAlzheimer disease and other dementiasDiarrhoeal diseasesDiabetes mellitusKidney diseases1.	Neonatal conditions2.	Ischaemic heart disease3.	Stroke4.	Lower respiratory infections5.	Diarrhoeal diseases6.	Road injury7.	Chronic obstructive pulmonary disease8.	Diabetes mellitus9.	Tuberculosis10.	Congenital anomalies�Causes of death by sexFor death and disability disaggregated by sex, annual global deaths and DALYs among women were around 15% lower than for men. However, women collectively spent about 20% more years living with disability (YLDs). In the past two decades, the greatest increase in female deaths has been from Alzheimer�s disease and other dementias, with nearly a threefold increase. These neurological disorders kill more females than males, with about 80% more deaths and 70% more DALYs for women than for men.���The top 10 causes of death fact sheet
	
	Date generated: 2022-02-09

It contains csv files divided into two folders: data and codes

	data: contains one csv file per indicator under "Life expectancy and life tables"
	
	codes: contains one csv file per disaggregation/dimension used in the data files
	


Hierarchy

	parent: mortality-and-global-health-estimates
	self: healthy-life-expectancy-(hale)
	children: 
		WHOSIS_000007	Healthy life expectancy (HALE) at age 60 (years)
		WHOSIS_000002	Healthy life expectancy (HALE) at birth (years)
		WHOSIS_000015	Life expectancy at age 60 (years)
		WHOSIS_000001	Life expectancy at birth (years)
		LIFE_0000000035	Life tables by WHO region (GHE: Life tables)
		LIFE_0000000031	lx - number of people left alive at age x (GHE: Life tables)
		LIFE_0000000032	ndx - number of people dying between ages x and x+n (GHE: Life tables)
		LIFE_0000000033	nLx - person-years lived between ages x and x+n (GHE: Life tables)
		LIFE_0000000029	nMx - age-specific death rate between ages x and x+n (GHE: Life tables)
		LIFE_0000000030	nqx - probability of dying between ages x and x+n  (GHE: Life tables)
		LIFE_0000000034	Tx - person-years lived above age x (GHE: Life tables)
	
